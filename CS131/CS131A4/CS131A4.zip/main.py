"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
CS131 - Artificial Intelligence

Implementation of a Sudoku Solver that solves a sudoku board using a
Constraint Satisfaction approach.

by Madelyn Silveira
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

from globals import TEST1, TEST2, TEST3, TEST4, TEST5, EMPTY, FULL
from search import run

run(TEST2)






