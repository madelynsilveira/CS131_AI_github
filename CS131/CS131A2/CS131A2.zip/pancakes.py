#
# CS131 - Artificial Intelligence
#
# Pancakes functions
# by Madelyn Silveira
# 

import sys

def printCakes(cakes):
    for i in range(10):
        if cakes[i] == 10: sys.stdout.write(str(cakes[i])+ ": ")
        else: sys.stdout.write(str(cakes[i])+ ":  ")
        while cakes[i] != 0:
            sys.stdout.write('---')
            cakes[i] = cakes[i] - 1
        sys.stdout.write('\n')


def flip(stack, index):
    new = stack
    stack = stack[::-1]
    for i in range(index):
        new[0] = stack[i]



